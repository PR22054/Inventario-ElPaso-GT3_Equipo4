-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-09-2025 a las 00:40:33
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dis115-3`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `categoria_id` int(7) NOT NULL,
  `categoria_nombre` varchar(50) NOT NULL,
  `categoria_tipo` varchar(50) NOT NULL,
  `categoria_ubicacion` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`categoria_id`, `categoria_nombre`, `categoria_tipo`, `categoria_ubicacion`) VALUES
(1, 'Herramientas Generales', 'Herramienta', 'Almacén A - Estante 1'),
(2, 'Herramientas de Precisión', 'Herramienta', 'Almacén A - Estante 2'),
(3, 'Herramientas Manuales', 'Herramienta', 'Almacén A - Estante 3'),
(4, 'Aceites y Lubricantes', 'Producto', 'Almacén B - Estante 1'),
(5, 'Equipos Eléctricos', 'Herramienta', 'Almacén A - Estante 4'),
(6, 'Repuestos y Filtros', 'Producto', 'Almacén B - Estante 2'),
(7, 'Baterías y Accesorios Eléctricos', 'Producto', 'Almacén C - Estante 1'),
(8, 'Neumáticos y Llantas', 'Producto', 'Almacén C - Estante 2'),
(9, 'Herramientas de Diagnóstico', 'Herramienta', 'Almacén A - Estante 5'),
(10, 'Consumibles de Taller', 'Producto', 'Almacén B - Estante 3'),
(11, 'Multímetros y Pinzas Amperimétricas', 'ambas', 'Herramientas para medir voltaje corriente y resistencia en circuitos eléctricos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `herramienta`
--

CREATE TABLE `herramienta` (
  `herramienta_id` int(20) NOT NULL,
  `herramienta_codigo` varchar(70) NOT NULL,
  `herramienta_nombre` varchar(70) NOT NULL,
  `herramienta_precio` decimal(30,2) NOT NULL,
  `herramienta_stock` int(25) NOT NULL,
  `herramienta_foto` varchar(500) NOT NULL,
  `categoria_id` int(7) NOT NULL,
  `usuario_id` int(10) NOT NULL,
  `necesita_mantenimiento` tinyint(1) DEFAULT 0,
  `estado_alarma` tinyint(1) DEFAULT 0,
  `requiere_mantenimiento` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `herramienta`
--

INSERT INTO `herramienta` (`herramienta_id`, `herramienta_codigo`, `herramienta_nombre`, `herramienta_precio`, `herramienta_stock`, `herramienta_foto`, `categoria_id`, `usuario_id`, `necesita_mantenimiento`, `estado_alarma`, `requiere_mantenimiento`) VALUES
(3, 'TAL123', 'Taladro Eléctrico', 100.00, 5, 'default.png', 1, 1, 0, 0, 0),
(6, 'HMT001', 'Taladro', 120.00, 10, '', 1, 1, 1, 1, 1),
(7, 'HMT002', 'Sierra Circular', 250.00, 5, '', 1, 1, 1, 1, 1),
(8, 'HMT003', 'Martillo', 15.00, 25, '', 1, 1, 0, 1, 1),
(9, 'HMT004', 'Llave Inglesa', 30.00, 15, '', 1, 1, 0, 0, 0),
(11, 'H001', 'Martillo de Carpintero', 12.50, 20, '1', 1, 1, 0, 0, 0),
(12, 'H002', 'Destornillador Plano', 4.75, 50, '', 1, 1, 0, 0, 0),
(13, 'H003', 'Taladro Eléctrico Bosch', 75.00, 10, '', 3, 1, 0, 0, 0),
(14, 'H004', 'Llave Inglesa 12\"', 18.00, 15, '', 1, 1, 0, 0, 0),
(15, 'H013', 'Gato Hidráulico 3T', 180.00, 4, 'default.png', 1, 4, 0, 1, 1),
(16, 'H014', 'Compresor de Aire 100L', 300.00, 2, 'default.png', 1, 4, 0, 0, 0),
(17, 'H015', 'Carro de Herramientas Completo', 220.00, 3, 'default.png', 1, 5, 0, 0, 0),
(18, 'H016', 'Juego de Llaves Combinadas 20 pcs', 50.00, 15, 'default.png', 3, 4, 0, 0, 0),
(19, 'H017', 'Pinzas y Alicates', 35.00, 20, 'default.png', 3, 4, 1, 0, 1),
(20, 'H018', 'Destornilladores Profesionales', 25.00, 30, 'default.png', 3, 5, 0, 0, 1),
(21, 'H019', 'Martillo de Carpintero', 15.00, 12, 'default.png', 3, 4, 0, 0, 0),
(22, 'H020', 'Taladro Inalámbrico Profesional', 120.00, 6, 'default.png', 5, 4, 1, 1, 1),
(23, 'H021', 'Pulidora Eléctrica Automotriz', 150.00, 4, 'default.png', 5, 5, 0, 0, 0),
(24, 'H022', 'Amoladora Angular', 70.00, 8, 'default.png', 5, 5, 0, 0, 1),
(25, 'H023', 'Scanner OBD2 Profesional', 180.00, 5, 'default.png', 9, 5, 1, 1, 1),
(26, 'H024', 'Multímetro Digital Avanzado', 45.00, 10, 'default.png', 9, 4, 0, 0, 0),
(27, 'H025', 'Detector de Fugas de Vacío', 60.00, 3, 'default.png', 9, 5, 1, 1, 1),
(29, 'H027', 'Cables de Arranque 600A', 30.00, 10, 'default.png', 7, 4, 0, 0, 1),
(30, 'H028', 'Llanta 195/60 R15', 80.00, 12, 'default.png', 8, 4, 0, 0, 0),
(31, 'H029', 'Llanta 205/55 R16', 90.00, 10, 'default.png', 8, 5, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mantenimiento`
--

CREATE TABLE `mantenimiento` (
  `mantenimiento_id` int(10) NOT NULL,
  `mantenimiento_persona` varchar(70) NOT NULL,
  `mantenimiento_detalles` varchar(255) NOT NULL,
  `mantenimiento_fecha1` date NOT NULL,
  `mantenimiento_fecha2` date NOT NULL,
  `herramienta_id` int(20) NOT NULL,
  `usuario_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `mantenimiento`
--

INSERT INTO `mantenimiento` (`mantenimiento_id`, `mantenimiento_persona`, `mantenimiento_detalles`, `mantenimiento_fecha1`, `mantenimiento_fecha2`, `herramienta_id`, `usuario_id`) VALUES
(1, '7', 'Fugas de aceite hidráulico visibles en el cilindro.', '2025-09-16', '2025-09-21', 15, 7),
(2, '6', 'Baja potencia / no mantiene torque.', '2025-09-28', '2025-10-04', 20, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `producto_id` int(20) NOT NULL,
  `producto_codigo` varchar(70) NOT NULL,
  `producto_nombre` varchar(70) NOT NULL,
  `producto_precio` decimal(30,2) NOT NULL,
  `producto_stock` int(25) NOT NULL,
  `producto_foto` varchar(500) NOT NULL,
  `categoria_id` int(7) NOT NULL,
  `usuario_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`producto_id`, `producto_codigo`, `producto_nombre`, `producto_precio`, `producto_stock`, `producto_foto`, `categoria_id`, `usuario_id`) VALUES
(1, 'P001', 'Aceite Motor 10W40', 15.00, 50, 'Aceite_Motor_10W40_62.png', 4, 1),
(2, 'P002', 'Filtro de Aceite', 8.00, 30, 'Filtro_de_Aceite_100.png', 4, 7),
(3, 'P003', 'Bateria 12V 60Ah', 120.00, 10, 'Bateria_12V_60Ah_72.png', 5, 5),
(4, 'INV102\r\n', 'Gato Hidráulico 2T', 120.00, 10, 'Gato_Hidráulico_2T_57.png', 1, 4),
(5, 'INV203', 'Medidor de precisión de Aceite', 180.00, 8, '', 2, 5),
(60, 'INV103', 'Carro de Herramientas', 180.00, 8, 'Carro_de_Herramientas_75.png', 1, 4),
(61, 'INV201', 'Torquímetro 1-50Nm', 35.00, 15, '', 2, 5),
(62, 'INV202', 'Calibrador Vernier', 20.00, 20, 'Calibrador_Vernier_15.png', 2, 5),
(63, 'INV301', 'Llave Inglesa 12\"', 15.00, 25, '', 3, 4),
(64, 'INV302', 'Destornillador Juego 6 piezas', 10.00, 30, 'Destornillador_Juego_6_piezas_63.png', 3, 4),
(65, 'INV303', 'Martillo de Goma', 8.00, 20, '', 3, 4),
(66, 'INV402', 'Aceite Transmisión 75W90', 18.00, 30, 'Aceite_Transmisión_75W90_41.png', 4, 4),
(67, 'INV403', 'Grasa Multiusos', 12.00, 40, 'Grasa_Multiusos_68.png', 4, 5),
(68, 'INV404', 'Líquido de Frenos DOT4', 8.50, 60, 'Líquido_de_Frenos_DOT4_70.png', 4, 4),
(70, 'INV502', 'Pulidora Eléctrica', 120.00, 5, '', 5, 4),
(71, 'INV601', 'Filtro de Aire Motor', 10.00, 40, 'Filtro_de_Aire_Motor_77.png', 6, 5),
(72, 'INV602', 'Filtro de Combustible', 12.00, 25, 'Filtro_de_Combustible_95.png', 6, 5),
(74, 'INV702', 'Cables de Arranque 400A', 25.00, 20, 'Cables_de_Arranque_400A_11.png', 7, 4),
(75, 'INV703', 'Bombilla Halógena H4', 5.00, 50, 'Bombilla_Halógena_H4_39.png', 7, 4),
(76, 'INV801', 'Llanta 195/65 R15', 75.00, 20, '', 8, 4),
(77, 'INV802', 'Llanta 205/55 R16', 85.00, 15, '', 8, 4),
(78, 'INV901', 'Scanner OBD2', 150.00, 8, '', 9, 5),
(79, 'INV902', 'Multímetro Digital', 40.00, 12, '', 9, 5),
(80, 'INV1001', 'Guantes de Seguridad', 5.50, 100, 'Guantes_de_Seguridad_1.png', 10, 5),
(81, 'INV1002', 'Cinta Aislante', 2.00, 200, 'Cinta_Aislante_36.png', 10, 5),
(82, 'INV1003', 'Paños de Limpieza', 1.50, 150, '', 10, 5),
(83, 'INV1004', 'Limpiador Multiusos', 3.25, 100, '', 10, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reporteh`
--

CREATE TABLE `reporteh` (
  `reporteh_id` int(7) NOT NULL,
  `reporteh_tipo` varchar(30) NOT NULL,
  `reporteh_persona` varchar(40) NOT NULL,
  `reporteh_detalles` varchar(200) NOT NULL,
  `herramienta_id` int(7) NOT NULL,
  `usuario_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `reporteh`
--

INSERT INTO `reporteh` (`reporteh_id`, `reporteh_tipo`, `reporteh_persona`, `reporteh_detalles`, `herramienta_id`, `usuario_id`) VALUES
(10, 'daño', 'Pedro López', 'Se rompió la broca del Taladro Bosch', 13, 6),
(11, 'robo', 'Luis García', 'Desapareció un destornillador del almacén', 12, 5),
(12, 'daño', 'Carlos Torres', 'Mango del martillo flojo', 8, 7),
(13, 'daño', 'Erick Pérez', 'Cable de taladro pelado', 20, 6),
(14, 'daño', 'Juan Antonio Rivas', 'Amoladora con engranaje desgastado', 22, 7),
(15, 'daño', 'Carlos Torres', 'Scanner OBD2 no enciende', 23, 6),
(16, 'daño', 'Pedro López', 'Gato hidráulico con fuga de aceite', 13, 6),
(17, 'robo', 'Luis García', 'Se llevó el martillo de carpintero', 11, 5),
(18, 'robo', 'Ana Martínez', 'Desapareció el multímetro digital', 24, 5),
(19, 'robo', 'José Ramírez', 'Batería 12V 70Ah extraviada', 26, 7),
(20, 'robo', 'Miguel Herrera', 'Llanta 205/55 R16 desaparecida', 29, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportep`
--

CREATE TABLE `reportep` (
  `reportep_id` int(7) NOT NULL,
  `reportep_tipo` varchar(30) NOT NULL,
  `reportep_persona` varchar(40) NOT NULL,
  `reportep_detalles` varchar(200) NOT NULL,
  `reportep_cantidad` int(11) NOT NULL,
  `producto_id` int(7) NOT NULL,
  `usuario_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `reportep`
--

INSERT INTO `reportep` (`reportep_id`, `reportep_tipo`, `reportep_persona`, `reportep_detalles`, `reportep_cantidad`, `producto_id`, `usuario_id`) VALUES
(7, 'robo', 'María López', 'Faltaron detergentes en el inventario', 12, 1, 4),
(8, 'daño', 'Carlos Pérez', 'Caja de guantes mojada y dañada', 8, 2, 5),
(9, 'pérdida', 'Ana Torres', 'No se encontraron rollos de cinta aislante', 15, 4, 6),
(26, 'daño', 'Pedro López', 'Aceite de motor derramado en estante', 5, 1, 6),
(27, 'daño', 'Carlos Torres', 'Filtro de aceite roto', 3, 2, 5),
(28, 'daño', 'Erick Pérez', 'Batería 12V golpeada y abollada', 2, 3, 6),
(29, 'robo', 'Luis García', 'Se llevaron 2 litros de aceite de transmisión', 2, 4, 5),
(30, 'robo', 'Ana Martínez', 'Desaparecieron guantes de seguridad', 10, 2, 5),
(31, 'robo', 'José Ramírez', 'Cinta aislante faltante en estante', 15, 5, 4),
(32, 'pérdida', 'Miguel Herrera', 'Limpiador multiusos extraviado', 5, 4, 5),
(33, 'pérdida', 'María López', 'Paños de limpieza faltantes', 8, 5, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `usuario_id` int(10) NOT NULL,
  `usuario_tipo` varchar(70) CHARACTER SET ucs2 COLLATE ucs2_spanish2_ci NOT NULL,
  `usuario_nombre` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL,
  `usuario_apellido` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL,
  `usuario_usuario` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL,
  `usuario_clave` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL,
  `usuario_email` varchar(70) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`usuario_id`, `usuario_tipo`, `usuario_nombre`, `usuario_apellido`, `usuario_usuario`, `usuario_clave`, `usuario_email`) VALUES
(1, 'admin', 'Administrador', 'Principal', 'Administrador', 'Administrador'),
(2, 'admin', 'Jose', 'Lemus', 'LR07038', 'LR07038', 'lr07038@ues.edu.sv'),
(3, 'admin', 'Jose Luis', 'Antonio', 'AV22025', 'AV22025', 'av22025@ues.edu.sv'),
(4, 'empleado', 'Alexandra', 'Gálvez', 'GR22078', 'GR22078', 'gr22078@ues.edu.sv'),
(5, 'empleado', 'Fernando', 'Cortez', 'CM21018', 'CM21018', 'cm21018@ues.edu.sv'),
(6, 'mecanico', 'Erick', 'Perez', 'PR22054', 'PR22054', 'pr22054@ues.edu.sv'),
(7, 'mecanico', 'Juan Antonio', 'Rivas Ruiz', 'RR20253', 'RR20253', 'rr20253@ues.edu.sv');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`categoria_id`);

--
-- Indices de la tabla `herramienta`
--
ALTER TABLE `herramienta`
  ADD PRIMARY KEY (`herramienta_id`),
  ADD KEY `categoria_id` (`categoria_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  ADD PRIMARY KEY (`mantenimiento_id`),
  ADD KEY `herramienta_id` (`herramienta_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`producto_id`),
  ADD KEY `categoria_id` (`categoria_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `reporteh`
--
ALTER TABLE `reporteh`
  ADD PRIMARY KEY (`reporteh_id`),
  ADD KEY `herramienta_id` (`herramienta_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `reportep`
--
ALTER TABLE `reportep`
  ADD PRIMARY KEY (`reportep_id`),
  ADD KEY `producto_id` (`producto_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`usuario_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `categoria_id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `herramienta`
--
ALTER TABLE `herramienta`
  MODIFY `herramienta_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  MODIFY `mantenimiento_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `producto_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT de la tabla `reporteh`
--
ALTER TABLE `reporteh`
  MODIFY `reporteh_id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `reportep`
--
ALTER TABLE `reportep`
  MODIFY `reportep_id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `usuario_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `herramienta`
--
ALTER TABLE `herramienta`
  ADD CONSTRAINT `herramienta_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`categoria_id`),
  ADD CONSTRAINT `herramienta_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usuario_id`);

--
-- Filtros para la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  ADD CONSTRAINT `mantenimiento_ibfk_1` FOREIGN KEY (`herramienta_id`) REFERENCES `herramienta` (`herramienta_id`),
  ADD CONSTRAINT `mantenimiento_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usuario_id`);

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`categoria_id`),
  ADD CONSTRAINT `producto_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usuario_id`);

--
-- Filtros para la tabla `reporteh`
--
ALTER TABLE `reporteh`
  ADD CONSTRAINT `reporteH_ibfk_1` FOREIGN KEY (`herramienta_id`) REFERENCES `herramienta` (`herramienta_id`),
  ADD CONSTRAINT `reporteH_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usuario_id`);

--
-- Filtros para la tabla `reportep`
--
ALTER TABLE `reportep`
  ADD CONSTRAINT `reporteP_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`producto_id`),
  ADD CONSTRAINT `reporteP_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usuario_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
