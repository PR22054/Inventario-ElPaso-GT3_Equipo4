<div class="container is-fluid mb-6">
    <div class="contenedor-destacado">
        <div style="text-align: right; margin-bottom: 1rem;">
            <button onclick="history.back()" 
                style="background-color: black; border: none; border-radius: 4px; padding: 0.4rem; cursor: pointer;">
                <span class="icon" style="color: white; font-size: 1rem;">
                    <i class="fas fa-arrow-left"></i>
                </span>
            </button>
        </div>
        <h1 class="title">Mantenimiento</h1>
        <h2 class="subtitle">Actualizar Mantenimiento</h2>

        <div class="container pb-6 pt-6">
            <?php
                include "./inc/btn_back.php";
                require_once "./php/main.php";

                $id = (isset($_GET['mantenimiento_id_up'])) ? $_GET['mantenimiento_id_up'] : 0;
                $id = limpiar_cadena($id);

                /*== Verificando mantenimiento ==*/
                $check_mantenimiento = conexion();
                $check_mantenimiento = $check_mantenimiento->query("SELECT * FROM mantenimiento WHERE mantenimiento_id='$id'");

                if($check_mantenimiento->rowCount() > 0){
                    $datos = $check_mantenimiento->fetch();
            ?>

            <div class="form-rest mb-6 mt-6"></div>
            
            <h2 class="title has-text-centered">
                Editar registro de: <strong><?php echo $datos['mantenimiento_persona']; ?></strong>
            </h2>

            <form action="./php/mantenimiento_actualizar.php" method="POST" class="FormularioAjax" autocomplete="off">
                
                <!-- ID oculto -->
                <input type="hidden" name="mantenimiento_id" value="<?php echo $datos['mantenimiento_id']; ?>" required>

                <div class="columns">
                    <!-- Usuario responsable -->
                    <div class="column">
                        <label class="label">Usuario Responsable</label>
                        <div class="select is-rounded is-fullwidth">
                            <select name="usuario_id" required>
                                <option value="">Seleccione un usuario</option>
                                <?php
                                    $conn = conexion();
                                    $usuarios_stmt = $conn->query("SELECT * FROM usuario");
                                    $usuarios = $usuarios_stmt->fetchAll(PDO::FETCH_ASSOC);

                                    foreach($usuarios as $u){
                                        $selected = ($datos['usuario_id'] == $u['usuario_id']) ? 'selected' : '';
                                        echo '<option value="'.$u['usuario_id'].'" '.$selected.'>'.$u['usuario_nombre'].' '.$u['usuario_apellido'].'</option>';
                                    }
                                ?>
                            </select>
                        </div>
                    </div>

                    <!-- Herramienta -->
                    <div class="column">
                        <label class="label">Herramienta</label>
                        <div class="select is-rounded is-fullwidth">
                            <select name="herramienta_id" required>
                                <option value="">Seleccione una herramienta</option>
                                <?php
                                    $herramientas_stmt = $conn->query("SELECT * FROM herramienta");
                                    $herramientas = $herramientas_stmt->fetchAll(PDO::FETCH_ASSOC);

                                    foreach($herramientas as $h){
                                        $selected = ($datos['herramienta_id'] == $h['herramienta_id']) ? 'selected' : '';
                                        echo '<option value="'.$h['herramienta_id'].'" '.$selected.'>'.$h['herramienta_nombre'].'</option>';
                                    }

                                    $conn = null; // cerramos conexión al final
                                ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="columns">
                    <!-- Detalles -->
                    <div class="column">
                        <label class="label">Detalles</label>
                        <input class="input" type="text" name="mantenimiento_detalles" maxlength="150" required
                               value="<?php echo $datos['mantenimiento_detalles']; ?>">
                    </div>

                    <!-- Fecha inicio -->
                    <div class="column">
                        <label class="label">Fecha Inicio</label>
                        <input class="input" type="date" name="mantenimiento_fecha1" required
                               value="<?php echo $datos['mantenimiento_fecha1']; ?>">
                    </div>

                    <!-- Fecha fin -->
                    <div class="column">
                        <label class="label">Fecha Fin</label>
                        <input class="input" type="date" name="mantenimiento_fecha2" required
                               value="<?php echo $datos['mantenimiento_fecha2']; ?>">
                    </div>
                </div>

                <!-- Botón -->
                <p class="has-text-centered mt-4">
                    <button type="submit" class="button is-success is-rounded">Actualizar</button>
                </p>
            </form>

            <?php 
                } else {
                    include "./inc/error_alert.php";
                }
                $check_mantenimiento = null;
            ?>
        </div>
    </div>
</div>

<style>
.contenedor-destacado {
    background-color: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.contenedor-destacado .columns {
    margin-left: 0;
    margin-right: 0;
}

.contenedor-destacado .column {
    padding-left: 10px;
    padding-right: 10px;
}
</style>
