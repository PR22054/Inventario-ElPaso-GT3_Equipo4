<div class="container is-fluid mb-6">
	<div class="contenedor-destacado">
		<div style="text-align: right; margin-bottom: 1rem;">
            <button onclick="history.back()" 
                style="background-color: black; border: none; border-radius: 4px; padding: 0.4rem; cursor: pointer;">
                <span class="icon" style="color: white; font-size: 1rem;">
                    <i class="fas fa-arrow-left"></i>
                </span>
            </button>
        </div>
		<h1 class="title">Usuarios</h1>
		<h2 class="subtitle">Nuevo usuario</h2>
	
		<div class="container pb-6 pt-6">

			<div class="form-rest mb-6 mt-6"></div>

			<form action="./php/usuario_guardar.php" method="POST" class="FormularioAjax" autocomplete="off" >
				<div class="columns">
					<div class="column">
						<div class="control">
							<label>Nombres</label>
							<input class="input" type="text" name="usuario_nombre" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}" maxlength="40" required 
								   oninput="capitalizeFirstLetter(this)" onkeypress="return soloLetras(event)">
						</div>
					</div>
					<div class="column">
						<div class="control">
							<label>Apellidos</label>
							<input class="input" type="text" name="usuario_apellido" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}" maxlength="40" required 
								   oninput="capitalizeFirstLetter(this)" onkeypress="return soloLetras(event)">
						</div>
					</div>
				</div>
				<div class="columns">
					<div class="column">
						<div class="control">
							<label>Usuario</label>
							<input class="input" type="text" name="usuario_usuario" pattern="[a-zA-Z0-9]{4,20}" maxlength="20" required >
						</div>
					</div>
					<div class="column">
						<div class="control">
							<label>Email</label>
							<input class="input" type="email" name="usuario_email" maxlength="70" >
						</div>
					</div>
				</div>
				<div class="columns">
					<div class="column">
						<div class="control">
							<label>Clave</label>
							<div class="field has-addons">
								<div class="control is-expanded">
									<input class="input" type="password" name="usuario_clave_1" pattern="[a-zA-Z0-9$@.-]{7,100}" maxlength="100" required id="password1">
								</div>
								<div class="control">
									<button type="button" class="button" onclick="togglePassword('password1', 'eyeIcon1')">
										<span class="icon" id="eyeIcon1">
											<i class="fas fa-eye"></i>
										</span>
									</button>
								</div>
							</div>
						</div>
					</div>
					<div class="column">
						<div class="control">
							<label>Repetir clave</label>
							<div class="field has-addons">
								<div class="control is-expanded">
									<input class="input" type="password" name="usuario_clave_2" pattern="[a-zA-Z0-9$@.-]{7,100}" maxlength="100" required id="password2">
								</div>
								<div class="control">
									<button type="button" class="button" onclick="togglePassword('password2', 'eyeIcon2')">
										<span class="icon" id="eyeIcon2">
											<i class="fas fa-eye"></i>
										</span>
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="columns">
			<div class="column">
				<div class="control">
					<label>Tipo de Usuario</label>
					<div class="user-type-selector">
						<div class="user-option" data-value="admin" onclick="selectUserType(this)">
							<span class="icon">💻</span>
							<span>Administrador</span>
						</div>
						<div class="user-option" data-value="empleado" onclick="selectUserType(this)">
							<span class="icon">👔</span>
							<span>Empleado</span>
						</div>
						<div class="user-option" data-value="mecanico" onclick="selectUserType(this)">
							<span class="icon">🔧</span>
							<span>Mecánico</span>
						</div>
					</div>            
				<input type="hidden" name="usuario_tipo" id="tipoUsuario" required>
				</div>
			</div>	  	
				</div>
				<p class="has-text-centered">
					<button type="submit" class="button is-info is-rounded">Guardar</button>
				</p>
			</form>
		</div>
	</div>
</div>

<script>
let selectedType = null;

function selectUserType(element) {
    // Quitar selección anterior
    if(selectedType) {
        selectedType.classList.remove('selected');
    }
    
    // Marcar nueva selección
    element.classList.add('selected');
    selectedType = element;
    
    // Actualizar campo oculto
    const value = element.getAttribute('data-value');
    document.getElementById('tipoUsuario').value = value;
}

// Función para poner la primera letra en mayúscula
function capitalizeFirstLetter(input) {
    if (input.value.length === 1) {
        input.value = input.value.toUpperCase();
    } else if (input.value.length > 1) {
        // Capitalizar primera letra de cada palabra
        input.value = input.value.replace(/\b\w/g, function(char) {
            return char.toUpperCase();
        });
    }
}

// Función para permitir solo letras y espacios
function soloLetras(event) {
    const charCode = event.keyCode || event.which;
    const charStr = String.fromCharCode(charCode);
    
    // Permitir solo letras, espacios y caracteres especiales del español
    if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]$/.test(charStr)) {
        event.preventDefault();
        return false;
    }
    return true;
}

// Función para mostrar/ocultar contraseña
function togglePassword(passwordId, eyeIconId) {
    const passwordInput = document.getElementById(passwordId);
    const eyeIcon = document.getElementById(eyeIconId);
    const icon = eyeIcon.querySelector('i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>

<!-- Estilos de varios -->
<style>
.user-option {
    flex: 1;
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    text-align: center;
    background: #f8f9fa;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
	color: #000; 
}
label {
    color: #000; 
    font-weight: 600; 
}
.user-type-selector {
    display: flex;
    gap: 10px;
    margin-top: 8px;
}
.input {
    border: 2px solid #ccc;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
}

.input:focus {
    border-color: #2196F3;
    box-shadow: 0 0 8px rgba(33, 150, 243, 0.2);
}
.user-option {
    flex: 1;
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    text-align: center;
    background: #f8f9fa;
}

.user-option:hover {
    background: #e9ecef;
    transform: translateY(-2px);
}

.user-option.selected {
    border-color: #2196F3;
    background: #e3f2fd;
    box-shadow: 0 2px 8px rgba(33,150,243,0.1);
}

.user-option .icon {
    display: block;
    font-size: 1.5em;
    margin-bottom: 5px;
}
</style>

