<div class="main-container">
    <div class="contenedor-destacado">
        <div style="text-align: right; margin-bottom: 1rem;">
            <button onclick="history.back()" 
                style="background-color: black; border: none; border-radius: 4px; padding: 0.4rem; cursor: pointer;">
                <span class="icon" style="color: white; font-size: 1rem;">
                    <i class="fas fa-arrow-left"></i>
                </span>
            </button>
        </div>
        <h1 class="title has-text-centered">Reporte</h1>
        <h2 class="subtitle has-text-centered">Actualizar Reporte de Productos</h2>

        <?php
        include "./inc/btn_back.php";
        require_once "./php/main.php";

        $id = (isset($_GET['reportep_id_up'])) ? $_GET['reportep_id_up'] : 0;
        $id = limpiar_cadena($id);

        $check_reportep = conexion();
        $check_reportep = $check_reportep->query("SELECT * FROM reportep WHERE reportep_id='$id'");

        if($check_reportep->rowCount() > 0){
            $datos = $check_reportep->fetch();
        ?>

        <form action="./php/reporteP_actualizar.php" method="POST" class="FormularioAjax" autocomplete="off">
            <input type="hidden" name="reportep_id" value="<?php echo $datos['reportep_id']; ?>" required>

            <div class="columns is-multiline">
                <!-- Usuario -->
                <div class="column is-half">
                    <div class="field">
                        <label class="label">Usuario</label>
                        <div class="control">
                            <div class="select is-fullwidth is-rounded">
                                <select name="reporteP_usuario" required>
                                    <option value="" disabled>Seleccione un usuario</option>
                                    <?php
                                        $usuarios = conexion()->query("SELECT * FROM usuario")->fetchAll();
                                        foreach ($usuarios as $row) {
                                            $selected = ($datos['usuario_asignado_id'] == $row['usuario_id']) ? 'selected' : '';
                                            echo '<option value="'.$row['usuario_id'].'" '.$selected.'>'.$row['usuario_nombre'].'</option>';
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Producto -->
                <div class="column is-half">
                    <div class="field">
                        <label class="label">Producto</label>
                        <div class="control">
                            <div class="select is-fullwidth is-rounded">
                                <select name="reporteP_producto" required>
                                    <option value="" disabled>Seleccione un producto</option>
                                    <?php
                                    $productos = conexion();
                                    $productos = $productos->query("SELECT * FROM producto");
                                    if ($productos->rowCount() > 0) {
                                        $productos = $productos->fetchAll();
                                        foreach ($productos as $row) {
                                            $selected = ($datos['producto_id'] == $row['producto_id']) ? 'selected' : '';
                                            echo '<option value="' . $row['producto_id'] . '" '.$selected.'>' . $row['producto_nombre'] . '</option>';
                                        }
                                    }
                                    $productos = null;
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Detalles -->
                <div class="column is-half">
                    <div class="field">
                        <label class="label">Detalles</label>
                        <div class="control">
                            <input class="input" type="text" name="reporteP_detalles"
                                   pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ().,$#\-\/ ]{1,150}" maxlength="150" required
                                   value="<?php echo $datos['reportep_detalles']; ?>">
                        </div>
                    </div>
                </div>

                <!-- Cantidad -->
                <div class="column is-one-quarter">
                    <div class="field">
                        <label class="label">Cantidad</label>
                        <div class="control">
                            <input class="input" type="number" name="reporteP_cantidad"
                                   pattern="[0-9]{1,25}" maxlength="25" required
                                   value="<?php echo $datos['reportep_cantidad']; ?>">
                        </div>
                    </div>
                </div>

                <!-- Tipo de Incidencia -->
                <div class="column is-one-quarter">
                    <div class="field">
                        <label class="label">Tipo de Incidencia</label>
                        <div class="control">
                            <div class="select is-fullwidth is-rounded">
                                <select name="reporteP_tipo" required>
                                    <option value="">Seleccione una opción</option>
                                    <option value="robo" <?php echo ($datos['reportep_tipo']=='robo')?'selected':''; ?>>Robo</option>
                                    <option value="rota" <?php echo ($datos['reportep_tipo']=='rota')?'selected':''; ?>>Rota</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Botón -->
            <div class="field is-grouped is-grouped-centered mt-4">
                <div class="control">
                    <button type="submit" class="button is-success is-rounded">Actualizar</button>
                </div>
            </div>

            <!-- Contenedor para mostrar mensajes -->
            <div class="form-rest mt-4"></div>
        </form>

        <?php
        } else {
            include "./inc/error_alert.php";
        }
        $check_reportep = null;
        ?>

    </div>
</div>

<!-- Script AJAX -->
<script>
document.querySelector('.FormularioAjax').addEventListener('submit', function(e){
    e.preventDefault(); // evita submit normal
    let form = e.target;
    let data = new FormData(form);

    fetch(form.action, {
        method: 'POST',
        body: data
    })
    .then(res => res.text())
    .then(res => {
        document.querySelector('.form-rest').innerHTML = res; // muestra mensaje devuelto por PHP
    })
    .catch(err => console.error(err));
});
</script>

<style>
.main-container {
    display: flex;
    justify-content: center;
    align-items: flex-start;
    min-height: 100vh;
    padding: 20px;
    background-color: #f5f5f5;
}

.contenedor-destacado {
    width: 100%;
    max-width: 900px;
    background-color: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.contenedor-destacado .columns {
    margin-left: 0;
    margin-right: 0;
}

.contenedor-destacado .column {
    padding-left: 10px;
    padding-right: 10px;
}
</style>
