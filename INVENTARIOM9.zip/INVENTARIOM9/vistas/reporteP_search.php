<?php
    /* =========== INICIO DEL BLOQUE DE PROCESAMIENTO =========== */
    // Este bloque de PHP DEBE ser lo primero en el archivo.
    // Sin espacios, sin texto, sin HTML antes de él.

    require_once "./php/main.php";

    // Si se está enviando el formulario de búsqueda, se procesa aquí.
    if(isset($_POST['modulo_buscador'])){
        // El script buscador.php se encargará de validar,
        // establecer la sesión y redirigir.
        // Como no hay HTML antes, el header() funcionará.
        require_once "./php/buscador.php";
    }

    // Si se va a eliminar un producto, también se procesa aquí arriba.
    if(isset($_GET['reportep_id_del'])){
        require_once "./php/reporteP_eliminar.php";
    }

    /* =========== FIN DEL BLOQUE DE PROCESAMIENTO =========== */
?><!DOCTYPE html>
<html>
<head>
    <title>Productos</title>
</head>
<body>

<div class="container is-fluid mb-6">
    <div class="contenedor-destacado">
        <div style="text-align: right; margin-bottom: 1rem;">
            <button onclick="history.back()" 
                style="background-color: black; border: none; border-radius: 4px; padding: 0.4rem; cursor: pointer;">
                <span class="icon" style="color: white; font-size: 1rem;">
                    <i class="fas fa-arrow-left"></i>
                </span>
            </button>
        </div>
        <h1 class="title">Productos</h1>
        <h2 class="subtitle">Buscar producto</h2>

        <div class="container pb-6 pt-6">
            <?php
                // El resto de la lógica que solo MUESTRA información va aquí.

                if(!isset($_SESSION['busqueda_producto']) && empty($_SESSION['busqueda_producto'])){
            ?>
            <div class="columns">
                <div class="column">
                    <form action="" method="POST" autocomplete="off" >
                        <input type="hidden" name="modulo_buscador" value="producto">
                        <div class="field is-grouped">
                            <p class="control is-expanded">
                                <input class="input is-rounded" type="text" name="txt_buscador" placeholder="¿Qué estas buscando?" pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]{1,30}" maxlength="30" >
                            </p>
                            <p class="control">
                                <button class="button is-info" type="submit" >Buscar</button>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
            <?php }else{ ?>
            <div class="columns">
                <div class="column">
                    <form class="has-text-centered mt-6 mb-6" action="" method="POST" autocomplete="off" >
                        <input type="hidden" name="modulo_buscador" value="producto">
                        <input type="hidden" name="eliminar_buscador" value="producto">
                        <p>Estas buscando <strong>“<?php echo $_SESSION['busqueda_producto']; ?>”</strong></p>
                        <br>
                        <button type="submit" class="button is-danger is-rounded">Eliminar busqueda</button>
                    </form>
                </div>
            </div>
            <?php
                    if(!isset($_GET['page'])){
                        $pagina=1;
                    }else{
                        $pagina=(int) $_GET['page'];
                        if($pagina<=1){
                            $pagina=1;
                        }
                    }

                    $categoria_id = (isset($_GET['category_id'])) ? $_GET['category_id'] : 0;

                    $pagina=limpiar_cadena($pagina);
                    $url="index.php?vista=product_search&page="; /* <== */
                    $registros=15;
                    $busqueda=$_SESSION['busqueda_producto']; /* <== */

                    # Paginador producto #
                    require_once "./php/producto_lista.php";
                }
            ?>
        </div>
    </div>
</div>
 </body>
</html>