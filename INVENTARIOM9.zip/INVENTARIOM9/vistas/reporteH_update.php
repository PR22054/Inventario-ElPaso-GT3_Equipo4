<div class="main-container">
    <div class="contenedor-destacado">
        <div style="text-align: right; margin-bottom: 1rem;">
            <button onclick="history.back()" 
                style="background-color: black; border: none; border-radius: 4px; padding: 0.4rem; cursor: pointer;">
                <span class="icon" style="color: white; font-size: 1rem;">
                    <i class="fas fa-arrow-left"></i>
                </span>
            </button>
        </div>
        <h1 class="title has-text-centered">Reporte</h1>
        <h2 class="subtitle has-text-centered">Actualizar Reporte de Herramientas</h2>

        <?php
        include "./inc/btn_back.php";
        require_once "./php/main.php";

        $id = (isset($_GET['reporteh_id_up'])) ? $_GET['reporteh_id_up'] : 0;
        $id = limpiar_cadena($id);

        $check_reporteh = conexion();
        $check_reporteh = $check_reporteh->query("SELECT * FROM reporteh WHERE reporteh_id='$id'");

        if($check_reporteh->rowCount() > 0){
            $datos = $check_reporteh->fetch();
        ?>

        <form action="./php/reporteh_actualizar.php" method="POST" id="formActualizarReporteh" autocomplete="off">
            <input type="hidden" name="reporteh_id" value="<?php echo $datos['reporteh_id']; ?>" required>

            <div class="columns is-multiline">
                <!-- Usuario -->
                <div class="column is-half">
                    <label class="label">Usuario</label>
                    <div class="select is-fullwidth is-rounded">
                        <select name="usuario_id" required>
                            <option value="" selected>Seleccione un usuario</option>
                            <?php
                            $usuarios = conexion();
                            $usuarios = $usuarios->query("SELECT * FROM usuario");
                            if ($usuarios->rowCount() > 0) {
                                $usuarios = $usuarios->fetchAll();
                                foreach ($usuarios as $row) {
                                    $selected = ($datos['usuario_id'] == $row['usuario_id']) ? 'selected' : '';
                                    echo '<option value="'.$row['usuario_id'].'" '.$selected.'>'.$row['usuario_nombre'].'</option>';
                                }
                            }
                            $usuarios = null;
                            ?>
                        </select>
                    </div>
                </div>

                <!-- Herramienta -->
                <div class="column is-half">
                    <label class="label">Herramienta</label>
                    <div class="select is-fullwidth is-rounded">
                        <select name="herramienta_id" required>
                            <option value="" selected>Seleccione una opción</option>
                            <?php
                            $herramientas = conexion();
                            $herramientas = $herramientas->query("SELECT * FROM herramienta");
                            if ($herramientas->rowCount() > 0) {
                                $herramientas = $herramientas->fetchAll();
                                foreach ($herramientas as $row) {
                                    $selected = ($datos['herramienta_id'] == $row['herramienta_id']) ? 'selected' : '';
                                    echo '<option value="'.$row['herramienta_id'].'" '.$selected.'>'.$row['herramienta_nombre'].'</option>';
                                }
                            }
                            $herramientas = null;
                            ?>
                        </select>
                    </div>
                </div>

                <!-- Detalles -->
                <div class="column is-half">
                    <label class="label">Detalles</label>
                    <input class="input" type="text" name="reporteh_detalles" maxlength="150" required
                           value="<?php echo $datos['reporteh_detalles']; ?>">
                </div>

                <!-- Tipo -->
                <div class="column is-half">
                    <label class="label">Tipo de Incidencia</label>
                    <div class="select is-fullwidth is-rounded">
                        <select name="reporteh_tipo" required>
                            <option value="robo" <?php echo ($datos['reporteh_tipo']=='robo')?'selected':''; ?>>Robo</option>
                            <option value="rota" <?php echo ($datos['reporteh_tipo']=='rota')?'selected':''; ?>>Rota</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="field is-grouped is-grouped-centered mt-4">
                <button type="submit" class="button is-success is-rounded">Actualizar</button>
            </div>

            <div class="form-rest mt-4"></div>
        </form>

        <?php 
        } else {
            include "./inc/error_alert.php";
        }
        $check_reporteh = null;
        ?>

    </div>
</div>

<script>
document.getElementById('formActualizarReporteh').addEventListener('submit', function(e){
    e.preventDefault();
    let form = e.target;
    let data = new FormData(form);

    fetch(form.action, { method: 'POST', body: data })
        .then(res => res.text())
        .then(res => {
            document.querySelector('.form-rest').innerHTML = res;
        })
        .catch(err => console.error(err));
});
</script>
