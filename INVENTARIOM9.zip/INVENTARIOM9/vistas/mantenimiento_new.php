<div class="container is-fluid mb-6">
    <div class="contenedor-destacado">
        <div style="text-align: right; margin-bottom: 1rem;">
            <button onclick="history.back()" 
                style="background-color: black; border: none; border-radius: 4px; padding: 0.4rem; cursor: pointer;">
                <span class="icon" style="color: white; font-size: 1rem;">
                    <i class="fas fa-arrow-left"></i>
                </span>
            </button>
        </div>
        <h1 class="title">Mantenimientos</h1>
        <h2 class="subtitle">Registro de Mantenimientos</h2>

        <div class="container pb-6 pt-6">
            <?php require_once "./php/main.php"; ?>
            <div class="form-rest mb-6 mt-6"></div>

            <form action="./php/mantenimiento_guardar.php" method="POST" class="FormularioAjax" autocomplete="off" enctype="multipart/form-data">
                <div class="columns">
                    <div class="column">
                        <label>Usuario</label><br>
                        <div class="select is-rounded">
                            <select name="mantenimiento_persona" required>
                                <option value="" selected>Seleccione un usuario</option>
                                <?php
                                $usuarios = conexion()->query("SELECT * FROM usuario");
                                foreach($usuarios->fetchAll() as $row){
                                    echo '<option value="'.$row['usuario_id'].'">'.$row['usuario_nombre'].'</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="column">
                        <label>Herramienta</label><br>
                        <div class="select is-rounded">
                            <select name="mantenimiento_herramienta" required>
                                <option value="" selected>Seleccione una opción</option>
                                <?php
                                $herramientas = conexion()->query("SELECT * FROM herramienta WHERE necesita_mantenimiento=1");
                                foreach($herramientas->fetchAll() as $row){
                                    echo '<option value="'.$row['herramienta_id'].'">'.$row['herramienta_nombre'].'</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="columns">
                    <div class="column">
                        <div class="control">
                            <label>Detalles</label>
                            <input class="input" type="text" name="mantenimiento_detalles" pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ().,$#\-\/ ]{1,150}" maxlength="70" required>
                        </div>
                    </div>

                    <div class="column">
                        <div class="columns">
                            <div class="column">
                                <div class="control">
                                    <label>Fecha de Inicio</label>
                                    <input class="input" type="date" name="mantenimiento_fecha1" required>
                                </div>
                            </div>
                            <div class="column">
                                <div class="control">
                                    <label>Fecha de Finalización</label>
                                    <input class="input" type="date" name="mantenimiento_fecha2">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <p class="has-text-centered">
                    <button type="submit" class="button is-info is-rounded">Guardar</button>
                </p>
            </form>
        </div>
    </div>
</div>


<style>
label {
    color: #000; 
    font-weight: 600; 
}
</style>
