<?php
	$inicio = ($pagina>0) ? (($pagina * $registros)-$registros) : 0;
	$tabla="";

	$campos="producto.producto_id,producto.producto_codigo,producto.producto_nombre,producto.producto_precio,producto.producto_stock,producto.stock_maximo,producto.producto_foto,producto.categoria_id,producto.usuario_id,categoria.categoria_id,categoria.categoria_nombre,usuario.usuario_id,usuario.usuario_nombre,usuario.usuario_apellido";

	if(isset($busqueda) && $busqueda!=""){

		$consulta_datos="SELECT $campos FROM producto INNER JOIN categoria ON producto.categoria_id=categoria.categoria_id INNER JOIN usuario ON producto.usuario_id=usuario.usuario_id WHERE producto.producto_codigo LIKE '%$busqueda%' OR producto.producto_nombre LIKE '%$busqueda%' ORDER BY producto.producto_nombre ASC LIMIT $inicio,$registros";

		$consulta_total="SELECT COUNT(producto_id) FROM producto WHERE producto_codigo LIKE '%$busqueda%' OR producto_nombre LIKE '%$busqueda%'";

	}elseif($categoria_id>0){

		$consulta_datos="SELECT $campos FROM producto INNER JOIN categoria ON producto.categoria_id=categoria.categoria_id INNER JOIN usuario ON producto.usuario_id=usuario.usuario_id WHERE producto.categoria_id='$categoria_id' ORDER BY producto.producto_nombre ASC LIMIT $inicio,$registros";

		$consulta_total="SELECT COUNT(producto_id) FROM producto WHERE categoria_id='$categoria_id'";

	}else{

		$consulta_datos="SELECT $campos FROM producto INNER JOIN categoria ON producto.categoria_id=categoria.categoria_id INNER JOIN usuario ON producto.usuario_id=usuario.usuario_id ORDER BY producto.producto_nombre ASC LIMIT $inicio,$registros";

		$consulta_total="SELECT COUNT(producto_id) FROM producto";

	}

	$conexion=conexion();

	$datos = $conexion->query($consulta_datos);
	$datos = $datos->fetchAll();

	//Notificaciones para las accion de ediatar y eliminar,recarga  la pagina en 2 segundos y elimina la notificacion.
	if (isset($_GET['accion']) && $_GET['accion'] == 'eliminado') {
		echo '
		<div class="notification" 
			style="background:#fee2e2; color:#b91c1c; border-left:6px solid #ef4444; border-radius:10px; padding:1rem 1.5rem; margin:1.5rem auto; width:90%; max-width:700px; text-align:center; box-shadow:0 2px 10px rgba(0,0,0,0.05); animation:fadeIn 0.4s ease;">
			🗑️ <strong>Stock máximo eliminado correctamente.</strong>
		</div>
		<meta http-equiv="refresh" content="2;url=index.php?vista=product_list">
		';
	}
	if (isset($_GET['accion']) && $_GET['accion'] == 'editado') {
		echo '
		<div class="notification" 
			style="background:#dcfce7; color:#166534; border-left:6px solid #22c55e; border-radius:10px; padding:1rem 1.5rem; margin:1.5rem auto; width:90%; max-width:700px; text-align:center; box-shadow:0 2px 10px rgba(0,0,0,0.05); animation:fadeIn 0.4s ease;">
			⚙️ <strong>El Stock máximo del producto ha sido actualizado correctamente.</strong>
		</div>
		<meta http-equiv="refresh" content="2;url=index.php?vista=product_list">
		';
	}

	//Alerta de productos que superan su stock máximo
	$excedidos = [];

	foreach ($datos as $check) {
		if ($check['stock_maximo'] && $check['producto_stock'] > $check['stock_maximo']) {
			$excedidos[] = $check;
		}
	}
	if (count($excedidos) > 0) {
		echo '
		<div class="notification" 
		style="background:#e5e7eb; border-left:6px solid #6b7280; border-radius:12px; padding:2rem; margin:2rem auto; width:95%; max-width:900px; text-align:center; 
			box-shadow:0 3px 12px rgba(0,0,0,0.06); animation:fadeIn 0.4s ease;">
		<h2 class="title is-5" 
			style="color:#374151; margin-bottom:1rem; display:flex; justify-content:center; align-items:center; gap:8px;">
			⚠️ <span>Alerta de Stock Máximo de Productos</span>
		</h2>
		<p style="color:#4b5563; margin-bottom:1.5rem;"> Los siguientes productos superan su stock máximo permitido:</p>

		<div class="table-container" style="display:flex; justify-content:center;">
			<table class="table is-striped is-hoverable" style="background:white; border-radius:10px; overflow:hidden; width:90%; max-width:800px;">
				<thead style="background:#f5f5f5;">
					<tr style="color:#333; text-align:center;">
						<th>#</th>
						<th>Producto</th>
						<th>Stock Actual</th>
						<th>Stock Máximo</th>
						<th>Acciones</th>
					</tr>
				</thead>
				<tbody>';
		$num = 1;
		foreach ($excedidos as $item) {
		echo '
		<tr style="text-align:center;">
			<td>'.$num.'</td>
			<td><strong>'.$item['producto_nombre'].'</strong></td>
			<td>'.$item['producto_stock'].'</td>
			 	<td>
				<form method="POST" action="" class="is-flex is-justify-content-center is-align-items-center" style="gap:8px;">
					<input type="hidden" name="producto_id" value="'.$item['producto_id'].'">
					<input class="input is-small" type="number" name="nuevo_stock_maximo" 
						value="'.$item['stock_maximo'].'" min="0" step="1" 	style="width:80px; text-align:center;">
				</td>
			<td>
						<button type="submit" name="editar_stock" class="button is-link is-light is-small is-rounded">
							<span class="icon"><i class="fas fa-save"></i></span>
							<span>Editar</span>
						</button>
						<button type="submit" name="eliminar_stock" class="button is-danger is-light is-small is-rounded">
							<span class="icon"><i class="fas fa-trash-alt"></i></span>
							<span>Eliminar</span>
						</button>
				</form>
				</td>
		</tr>';
		$num++;
		}

		echo '
				</tbody>
			</table>
			</div>
		</div>';
	}


	//Logica de funcionamiento de los botones editar y eliminar
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$id = $_POST['producto_id'];

		if (isset($_POST['eliminar_stock'])) {
			$sql = $conexion->prepare("UPDATE producto SET stock_maximo = NULL WHERE producto_id = :id");
			$sql->execute([':id' => $id]);
			header("Location: index.php?vista=product_list&accion=eliminado");
			exit;
		}

		if (isset($_POST['editar_stock'])) {
			$nuevo = isset($_POST['nuevo_stock_maximo']) ? intval($_POST['nuevo_stock_maximo']) : 0;
			$sql = $conexion->prepare("UPDATE producto SET stock_maximo = :nuevo WHERE producto_id = :id");
			$sql->execute([':nuevo' => $nuevo, ':id' => $id]);
			header("Location: index.php?vista=product_list&accion=editado");//Recarga la vista con el parametro accion y permite que aparezca la notificacion de exito.
			exit;
		}
	}

	$total = $conexion->query($consulta_total);
	$total = (int) $total->fetchColumn();

	$Npaginas = ceil($total/$registros);

	if($total>=1 && $pagina<=$Npaginas){
		$contador=$inicio+1;
		$pag_inicio=$inicio+1;
		foreach($datos as $rows){

			$estado = '';//Muestra el estado siel producto supera su stock maximo tiene una etiqueta roja y si el stock esta dentro del maximo muestra una etiqueta verde.
			if ($rows['stock_maximo'] && $rows['producto_stock'] > $rows['stock_maximo']) {
				$estado = '<span class="tag is-danger is-light">⚠ Excedido</span>';
			} else {
				$estado = '<span class="tag is-success is-light">✔ Normal</span>';
			}
			$tabla .= '
			<article class="box is-shadowless" style="border:1px solid #eaeaea; border-radius:10px; margin-bottom:1rem; padding:1rem;">
				<div class="columns is-vcentered is-mobile">
					<!-- Imagen -->
					<div class="column is-narrow has-text-centered">
						<figure class="image is-96x96 mx-auto">';
							if(is_file("./img/producto/".$rows['producto_foto'])){
								$tabla .= '<img src="./img/producto/'.$rows['producto_foto'].'" style="object-fit:cover; border-radius:0;">';
							}else{
								$tabla .= '<img src="./img/producto.png" style="object-fit:cover; border-radius:0;">';
							}
						$tabla .= '
						</figure>
					</div>

					<!-- Datos principales -->
					<div class="column">
						<h2 class="title is-5 mb-1">'.$contador.' - '.$rows['producto_nombre'].'</h2>

						<div class="columns is-multiline is-mobile" style="font-size:0.9rem;">
							<div class="column is-half">
								<strong>Código:</strong> '.$rows['producto_codigo'].'<br>
								<strong>Stock:</strong> '.$rows['producto_stock'].'<br>
								<strong>Categoría:</strong> '.$rows['categoria_nombre'].'
							</div>
							<div class="column is-half">
								<strong>Precio:</strong> $'.$rows['producto_precio'].'<br>
								<strong>Stock Máximo:</strong> '.($rows['stock_maximo'] ?? 'No definido').'<br>
								<strong>Estado de Stock:</strong> '.$estado.'
							</div>
							<div class="column is-full mt-1">
								<strong>Registrado por:</strong> '.$rows['usuario_nombre'].' '.$rows['usuario_apellido'].'
							</div>
						</div>
					</div>

					<!-- Botones -->
					<div class="column is-narrow has-text-centered">
						<div class="buttons are-small is-flex is-flex-direction-column is-align-items-center">
							<a href="index.php?vista=product_img&product_id_up='.$rows['producto_id'].'" class="button is-info is-light is-rounded mb-2">
								<span class="icon"><i class="fas fa-image"></i></span>
								<span>Imagen</span>
							</a>
							<a href="index.php?vista=product_update&product_id_up='.$rows['producto_id'].'" class="button is-success is-light is-rounded mb-2">
								<span class="icon"><i class="fas fa-edit"></i></span>
								<span>Editar</span>
							</a>
							<a href="'.$url.$pagina.'&product_id_del='.$rows['producto_id'].'" 
								class="button is-danger is-light is-rounded" onclick="return confirm(\'¿Está seguro que desea eliminar el producto '.$rows['producto_nombre'].'?\')">
								<span class="icon"><i class="fas fa-trash-alt"></i></span>
								<span>Eliminar</span>
							</a>
						</div>
					</div>
				</div>
			</article>';
			$contador++;
		}
		$pag_final=$contador-1;
	}else{
		if($total>=1){
			$tabla.='
				<p class="has-text-centered" >
					<a href="'.$url.'1" class="button is-link is-rounded is-small mt-4 mb-4">
						Haga clic acá para recargar el listado
					</a>
				</p>
			';
		}else{
			$tabla.='<p class="has-text-centered">No hay registros en el sistema</p>';
		}
	}
	//Muestra cuantos productos se ven y cuantos hay en total.
	if($total>0 && $pagina<=$Npaginas){
		$tabla.='<p class="has-text-right mt-3">
			Mostrando productos <strong>'.$pag_inicio.'</strong> al 
			<strong>'.$pag_final.'</strong> de un total de 
			<strong>'.$total.'</strong>
		</p>';
	}

	$conexion=null;
	echo $tabla;
	if($total>=1 && $pagina<=$Npaginas){
		echo paginador_tablas($pagina,$Npaginas,$url,7);//Llama a la funcion que crea los botones de paginanción.
	}

?>
<style>
/*Efceto para que las notificaciones aparezcan suavemente desde arriba, lo usan la alerta y notificaciones.*/
@keyframes fadeIn {
	from { opacity: 0; transform: translateY(-6px); }
	to { opacity: 1; transform: translateY(0); }
}
</style>