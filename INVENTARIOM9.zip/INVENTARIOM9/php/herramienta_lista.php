<?php
	$inicio = ($pagina>0) ? (($pagina * $registros)-$registros) : 0; 
	$tabla="";

	$campos="herramienta.herramienta_id,herramienta.herramienta_codigo,herramienta.herramienta_nombre,herramienta.herramienta_precio,herramienta.herramienta_stock,herramienta.herramienta_foto,herramienta.categoria_id,herramienta.usuario_id,categoria.categoria_id,categoria.categoria_nombre,usuario.usuario_id,usuario.usuario_nombre,usuario.usuario_apellido";

	// ============== CONSTRUCCIÓN DE LA CONSULTA BASE ==============
	$where_conditions = [];
	$order_by = "herramienta.herramienta_nombre ASC"; // Orden por defecto

	// Condición de búsqueda
	if(isset($busqueda) && $busqueda!=""){
		$where_conditions[] = "(herramienta.herramienta_codigo LIKE '%$busqueda%' OR herramienta.herramienta_nombre LIKE '%$busqueda%')";
	}

	// Condición de categoría (desde vista de categoría o desde filtros)
	if(isset($categoria_id) && !empty($categoria_id) && $categoria_id > 0){
		$where_conditions[] = "herramienta.categoria_id='$categoria_id'";
	}elseif(isset($_SESSION['filtro_categoria']) && $_SESSION['filtro_categoria'] != ""){
		$categoria_filtrada = limpiar_cadena($_SESSION['filtro_categoria']);
		$where_conditions[] = "herramienta.categoria_id='$categoria_filtrada'";
	}

	// ============== FILTRO DE STOCK ==============
	if(isset($_SESSION['filtro_stock']) && $_SESSION['filtro_stock'] != ""){
		$filtro_stock = $_SESSION['filtro_stock'];
		switch($filtro_stock){
			case 'sin_stock':
				$where_conditions[] = "herramienta.herramienta_stock = 0";
				break;
			case 'bajo':
				$where_conditions[] = "herramienta.herramienta_stock > 0 AND herramienta.herramienta_stock < 5";
				break;
			case 'normal':
				$where_conditions[] = "herramienta.herramienta_stock >= 5";
				break;
		}
	}

	// ============== ORDEN (PRIORIDAD: El último filtro aplicado) ==============
	// Se evalúan en orden de prioridad: precio > nombre > asignación
	
	if(isset($_SESSION['filtro_ordenar_precio']) && $_SESSION['filtro_ordenar_precio'] != ""){
		$orden_precio = ($_SESSION['filtro_ordenar_precio'] == 'ASC') ? 'ASC' : 'DESC';
		$order_by = "herramienta.herramienta_precio $orden_precio";
	}
	elseif(isset($_SESSION['filtro_ordenar_nombre']) && $_SESSION['filtro_ordenar_nombre'] != ""){
		$orden_nombre = ($_SESSION['filtro_ordenar_nombre'] == 'ASC') ? 'ASC' : 'DESC';
		$order_by = "herramienta.herramienta_nombre $orden_nombre";
	}
	elseif(isset($_SESSION['filtro_ordenar_asignacion']) && $_SESSION['filtro_ordenar_asignacion'] != ""){
		$orden_asignacion = ($_SESSION['filtro_ordenar_asignacion'] == 'ASC') ? 'ASC' : 'DESC';
		$order_by = "herramienta.herramienta_codigo $orden_asignacion";
	}

	// ============== CONSTRUCCIÓN FINAL DE LA CONSULTA ==============
	$where_clause = "";
	if(count($where_conditions) > 0){
		$where_clause = "WHERE " . implode(" AND ", $where_conditions);
	}

	$consulta_datos = "SELECT $campos FROM herramienta 
					   INNER JOIN categoria ON herramienta.categoria_id=categoria.categoria_id 
					   INNER JOIN usuario ON herramienta.usuario_id=usuario.usuario_id 
					   $where_clause 
					   ORDER BY $order_by 
					   LIMIT $inicio,$registros";

	// Consulta para contar total de registros
	$consulta_total = "SELECT COUNT(herramienta_id) FROM herramienta 
					   INNER JOIN categoria ON herramienta.categoria_id=categoria.categoria_id 
					   $where_clause";

	// ============== EJECUCIÓN DE CONSULTAS ==============
	$conexion = conexion();

	$datos = $conexion->query($consulta_datos);
	$datos = $datos->fetchAll();

	$total = $conexion->query($consulta_total);
	$total = (int) $total->fetchColumn();

	$Npaginas = ceil($total/$registros);

	// ============== GENERACIÓN DE LA TABLA ==============
	if($total>=1 && $pagina<=$Npaginas){
		$contador=$inicio+1;
		$pag_inicio=$inicio+1;
		foreach($datos as $rows){
			$tabla.='
				<article class="media has-background-transparent">
			        <figure class="media-left">
			            <p class="image is-64x64">';
			            if(is_file("./img/herramienta/".$rows['herramienta_foto'])){
			            	$tabla.='<img src="./img/herramienta/'.$rows['herramienta_foto'].'">';
			            }else{
			            	$tabla.='<img src="./img/herramienta.png">';
			            }
			   $tabla.='</p>
			        </figure>
			        <div class="media-content">
			            <div class="content">
			              <p>
			                <strong>'.$contador.' - '.$rows['herramienta_nombre'].'</strong><br>
			                <strong>ASIGNACION:</strong> '.$rows['herramienta_codigo'].', <strong>PRECIO:</strong> $'.$rows['herramienta_precio'].', <strong>STOCK:</strong> '.$rows['herramienta_stock'].', <strong>CATEGORIA:</strong> '.$rows['categoria_nombre'].', <strong>REGISTRADO POR:</strong> '.$rows['usuario_nombre'].' '.$rows['usuario_apellido'].'
			              </p>
			            </div>
			            <div class="has-text-right">
							<a href="index.php?vista=herramienta_img&herramienta_id_up='.$rows['herramienta_id'].'" class="button is-info is-rounded is-small">
								<span class="icon is-small"><i class="fas fa-image"></i></span>
								<span>Imagen</span>
							</a>

							
							<a href="index.php?vista=herramienta_vista_detallada&herramienta_id='.$rows['herramienta_id'].'" class="button is-warning is-rounded is-small">
								<span class="icon is-small"><i class="fas fa-search"></i></span>
								<span>Vista Detallada</span>
							</a>


							<a href="index.php?vista=herramienta_update&herramienta_id_up='.$rows['herramienta_id'].'" class="button is-success is-rounded is-small">
								<span class="icon is-small"><i class="fas fa-edit"></i></span>
								<span>Actualizar</span>
							</a>
							<a href="'.$url.$pagina.'&tool_id_del='.$rows['herramienta_id'].'" 
								class="button is-danger is-rounded is-small"
								onclick="return confirm(\'¿Está seguro que desea eliminar la herramienta '.$rows['herramienta_nombre'].'?\')">
								<span class="icon is-small"><i class="fas fa-trash-alt"></i></span>
								<span>Eliminar</span>
							</a>
						</div>
			        </div>
			    </article>

			    <hr>
            ';
            $contador++;
		}
		$pag_final=$contador-1;
	}else{
		if($total>=1){
			$tabla.='
				<p class="has-text-centered" >
					<a href="'.$url.'1" class="button is-link is-rounded is-small mt-4 mb-4">
						Haga clic acá para recargar el listado
					</a>
				</p>
			';
		}else{
			$tabla.='
				<p class="has-text-centered" >No hay registros en el sistema</p>
			';
		}
	}

	if($total>0 && $pagina<=$Npaginas){
		$tabla.='<p class="has-text-right">Mostrando Herramientas <strong>'.$pag_inicio.'</strong> al <strong>'.$pag_final.'</strong> de un <strong>total de '.$total.'</strong></p>';
	}

	$conexion=null;
	echo $tabla;

	if($total>=1 && $pagina<=$Npaginas){
		echo paginador_tablas($pagina,$Npaginas,$url,7);
	}