<?php
require_once "main.php";

// Recibir datos del formulario
$mantenimiento_id     = limpiar_cadena($_POST['mantenimiento_id']);
$usuario_id           = limpiar_cadena($_POST['usuario_id']);
$herramienta_id       = limpiar_cadena($_POST['herramienta_id']);
$detalles             = limpiar_cadena($_POST['mantenimiento_detalles']);
$fecha1               = limpiar_cadena($_POST['mantenimiento_fecha1']);
$fecha2               = limpiar_cadena($_POST['mantenimiento_fecha2']);

// Verificar que el mantenimiento existe
$check_mantenimiento = conexion();
$check_mantenimiento = $check_mantenimiento->query("SELECT * FROM mantenimiento WHERE mantenimiento_id='$mantenimiento_id'");

if($check_mantenimiento->rowCount() <= 0){
    echo '
    <div class="notification is-danger is-light">
        <strong>Error:</strong> El mantenimiento no existe.
    </div>';
    exit();
}
$check_mantenimiento = null;

// Preparar actualización
$conexion = conexion();
$update = $conexion->prepare("
    UPDATE mantenimiento 
    SET usuario_id=:usuario_id,
        herramienta_id=:herramienta_id,
        mantenimiento_detalles=:detalles,
        mantenimiento_fecha1=:fecha1,
        mantenimiento_fecha2=:fecha2
    WHERE mantenimiento_id=:id
");

// Enlazar parámetros
$update->bindParam(":usuario_id", $usuario_id);
$update->bindParam(":herramienta_id", $herramienta_id);
$update->bindParam(":detalles", $detalles);
$update->bindParam(":fecha1", $fecha1);
$update->bindParam(":fecha2", $fecha2);
$update->bindParam(":id", $mantenimiento_id);

// Ejecutar
if($update->execute()){
    echo '
    <div class="notification is-success is-light">
        <strong>¡Actualizado!</strong><br>
        El mantenimiento se actualizó correctamente.
    </div>';
}else{
    echo '
    <div class="notification is-danger is-light">
        <strong>Error:</strong> No se pudo actualizar el mantenimiento.
    </div>';
}

$conexion = null;
