<?php
require_once "main.php";

/*== Almacenando id ==*/
$id = limpiar_cadena($_POST['reporteh_id'] ?? '');

/*== Verificando producto ==*/
$check_reporteh = conexion();
$check_reporteh = $check_reporteh->query("SELECT * FROM reporteh WHERE reporteh_id='$id'");

if($check_reporteh->rowCount() <= 0){
    echo '
        <div class="notification is-danger is-light">
            <strong>¡Ocurrio un error inesperado!</strong><br>
            El reporte no existe en el sistema
        </div>
    ';
    exit();
} else {
    $datos = $check_reporteh->fetch();
}
$check_reporteh = null;

/*== Almacenando datos ==*/
$tipo        = limpiar_cadena($_POST['reporteh_tipo'] ?? '');
$persona     = limpiar_cadena($_POST['usuario_id'] ?? '');
$detalles    = limpiar_cadena($_POST['reporteh_detalles'] ?? '');
$herramienta = limpiar_cadena($_POST['herramienta_id'] ?? '');

/*== Verificando campos obligatorios ==*/
if($tipo == "" || $persona == "" || $detalles == "" || $herramienta == ""){
    echo '
        <div class="notification is-danger is-light">
            <strong>¡Ocurrio un error inesperado!</strong><br>
            No has llenado todos los campos que son obligatorios
        </div>
    ';
    exit();
}

/*== Verificando integridad de los datos ==*/
if(verificar_datos("[a-zA-Z0-9- ]{1,70}", $tipo)){
    echo '
        <div class="notification is-danger is-light">
            <strong>¡Ocurrio un error inesperado!</strong><br>
            El tipo no coincide con el formato solicitado
        </div>
    ';
    exit();
}

if(verificar_datos("[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ().,$#\-\/ ]{1,150}", $detalles)){
    echo '
        <div class="notification is-danger is-light">
            <strong>¡Ocurrio un error inesperado!</strong><br>
            Los detalles no coinciden con el formato solicitado
        </div>
    ';
    exit();
}

/*== Actualizando datos ==*/
$actualizar_reporteh = conexion();
$actualizar_reporteh = $actualizar_reporteh->prepare("
    UPDATE reporteh 
    SET reporteh_tipo=:tipo,
        reporteh_detalles=:detalles, 
        herramienta_id=:herramienta, 
        usuario_id=:persona
    WHERE reporteh_id=:id
");

$marcadores = [
    ":tipo" => $tipo,
    ":detalles" => $detalles,
    ":herramienta" => $herramienta,
    ":persona" => $persona,
    ":id" => $id
];

if($actualizar_reporteh->execute($marcadores)){
    echo '
        <div class="notification is-info is-light">
            <strong>¡REPORTE ACTUALIZADO!</strong><br>
            El reporte se actualizó con éxito
        </div>
    ';
} else {
    echo '
        <div class="notification is-danger is-light">
            <strong>¡Ocurrio un error inesperado!</strong><br>
            No se pudo actualizar el reporte, por favor intente nuevamente
        </div>
    ';
}
$actualizar_reporteh = null;
